﻿using MathNet.Numerics.LinearAlgebra.Double;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LNU.FA.Fourth
{
    public class Solver
    {
        private int N;
        private double H;

        private double BaseFunc(double x, int index)
        {
            return Math.Pow(x, index);
        }

        private double Sacalar1(double[] y, double[] g)
        {
            var tempList = y.Zip(g, (a, b) => a * b);
            return Intergal(tempList.ToArray());
        }

        private double[] weights;

        public void Solve(Point[] points, int degree)
        {
            N = points.Length;
            H = points[1].X - points[0].X;
            Matrix matrix = new DenseMatrix(points.Length, degree);
            Vector vector = new DenseVector(points.Length);
            
            for (int i = 0; i < points.Length; i++)
            {
                for (int j = 0; j < degree; j++)
                {
                    var phiI = BaseFunc(points[j].X, i);
                    var phiJ = BaseFunc(points[j].X, j);
                    var array = points.Select(el => el.X).Select(el => BaseFunc(el, i) * BaseFunc(el, j));

                    matrix[i, j] = Intergal(array.ToArray());
                }
                var yArray = points.Select(el => el.Y).Select(el => BaseFunc(el, i) * BaseFunc(el, i));
                vector[i] = Intergal(yArray.ToArray());
            }
            weights = matrix.Solve(vector).ToArray();
        }

        public double Run(double x)
        {
            double result = 0;
            for (int i = 0; i < weights.Length; i++)
            {
                result += BaseFunc(x, i) * weights[i];
            }
            return result;
        }

        private double Intergal(double[] array)
        {
            double result = default(double);

            for (int i = 0; i < N; i++)
            {
                result += array[i] * H;
                i++;
            }

            return result;
        }
    }
}
