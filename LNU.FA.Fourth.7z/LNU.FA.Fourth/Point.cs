﻿namespace LNU.FA.Fourth
{
    public class Point
    {
        public double X { get; set; }
        public double Y { get; set; }
    }
}
